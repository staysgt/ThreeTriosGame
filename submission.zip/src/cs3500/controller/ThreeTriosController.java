package cs3500.controller;

public class ThreeTriosController {
}
