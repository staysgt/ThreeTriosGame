package cs3500.view;


import javax.swing.*;
import java.awt.*;

/**
 * This is the graphics class and incoorporates create.
 */
public class FunGraphics extends JPanel {


  protected Graphics create(int x, int y, int width, int height) {
    return create(x, y, width, height);
  }
}

