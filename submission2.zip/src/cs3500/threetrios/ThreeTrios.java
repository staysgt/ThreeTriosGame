package cs3500.threetrios;

import cs3500.model.GameGridModel;
import cs3500.model.NESWCard;

public final class ThreeTrios {
  public static void main(String[] args) {
    GameGridModel<NESWCard> model = new GameGridModel<>();
//    YourView view = new YourView(model);
//    view.setVisible(true);
  }
}
