package cs3500.controller.strategy;

public enum Strategies {
  FLIP_MOST,
  MINIMAX,
  CORNERS,
  CARD_LESS_LIKELY;
}
