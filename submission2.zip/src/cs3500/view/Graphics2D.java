package cs3500.view;

public class Graphics2D {
}
