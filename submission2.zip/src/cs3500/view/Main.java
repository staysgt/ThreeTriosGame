package cs3500.view;

public class Main {

  public static void main(String[] args) {
    GameGridFrameView frameView = new GameGridFrameView(400, 400);

    frameView.showFrame();
  }
}
