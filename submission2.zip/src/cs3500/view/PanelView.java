package cs3500.view;


import cs3500.model.Card;

public interface PanelView{

  void showPanel();


}
