package cs3500.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;

import cs3500.model.Card;
import cs3500.model.GameGrid;
import cs3500.model.GameGridModel;

/**
 * Testing class for testing the decorators.
 */
public class StrategyDecoratorTests<C extends Card> {

  private final GameGrid<C> modelNH = new GameGridModel<>(new Random(3));
  private final ConfigurationFileReader noHoles;
  private final NESWCardFileReader<C> cardFile;

  {
    try {
      ConfigurationFileReader conFigFile = new ConfigurationFileReader("src" + File.separator + "walkableholes");
      cardFile = new NESWCardFileReader<>("src/cardsexample");
      NESWCardFileReader<C> badCardFile = new NESWCardFileReader<>("src/notenoughcards");
      noHoles = new ConfigurationFileReader("src/noholes");
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
  }

}
