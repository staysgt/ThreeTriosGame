package cs3500.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.*;


public class Panel extends JPanel{

}


