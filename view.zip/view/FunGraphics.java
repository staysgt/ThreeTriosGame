package cs3500.view;

import cs3500.model.ReadOnlyGameGridModel;

import java.awt.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

public class FunGraphics extends Panel implements GraphicsView {

    //private final ReadOnlyGameGridModel model;

    protected void mouseClicked(MouseEvent e) {
        System.out.println(e.getX() + "," + e.getY());
    }

    @Override
    public void update(Graphics g) {

    }




}
