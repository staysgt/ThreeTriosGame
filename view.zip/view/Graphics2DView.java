package cs3500.view;

import cs3500.model.GameGridModel;
import cs3500.model.ReadOnlyGameGridModel;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Path2D;


public class Graphics2DView extends FunGraphics implements Graphics2DInf {

    ReadOnlyGameGridModel model = new GameGridModel();

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        fillRect(g2d, 0, 0, getWidth(), getHeight());
        drawLines(g2d, 0, 0, getWidth(), getHeight());
    }

    @Override
    public Graphics create() {
        return super.create();
    }

    @Override
    public void fillRect(Graphics2D g2d, int x, int y, int width, int height) {
        for (int row = 0; row < x; row++) {
            for (int col = 0; col < y; col++) {
                int rectX = col * width;
                int rectY = row * height;

                if (model.isCellHole(row, col)) {
                    g2d.setColor(Color.GRAY);
                } else {
                    g2d.setColor(Color.YELLOW);
                }

                g2d.fillRect(rectX, rectY, width, height);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(rectX, rectY, width, height);
            }
        }
    }

    @Override
    public void drawLines(Graphics2D g2d, int x, int y, int width, int height) {
        g2d.setColor(Color.BLACK);
        for (int row = 0; row < x; row++) {
            int lineY = row * height;
            g2d.drawLine(0, lineY, x * width, lineY);
        }

        for (int col = 0; col < y; col++) {
          int lineX = col * width;
          g2d.drawLine(lineX, 0, lineX, y * height);
        }
    }

    protected void setFont(JLabel label, String name, int style, int size) {
        label.setFont(new Font(name, style, size));
    }


    public class CardPlacement extends Path2D.Double {

        private double width;
        private double height;

        public CardPlacement(double x, double y, double width, double height) {
            this.width = width;
            this.height = height;
            cardSize(x, y);
        }

        private void cardSize(double x, double y) {
            moveTo(x, y);
            lineTo(x + width, y);
            lineTo(x + width, y + height);
            lineTo(x, y + height);
        }

        public void render(Graphics2D g2d) {
            g2d.draw(this);
        }
    }

}
