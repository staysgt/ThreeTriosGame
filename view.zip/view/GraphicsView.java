package cs3500.view;

import java.awt.*;

public interface GraphicsView {


  void update(Graphics g);


}
