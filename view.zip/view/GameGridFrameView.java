package cs3500.view;

import javax.swing.*;
import java.awt.*;

public class GameGridFrameView extends JFrame implements FrameView {

  @Override
  public void showFrame() {
    setVisible(true);
  }

}

