package cs3500.view;

public interface FrameView {

  void showFrame();

}
