package cs3500.view;

import javax.swing.*;
import java.awt.*;

public final class PView {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Three Trios");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(0, 0);
        frame.setPreferredSize(new Dimension(1200, 1200));

        frame.add(new FunGraphics());
        //frame.add(new Graphics2DView());

        frame.pack();
        frame.setVisible(true);


    }

}
