package cs3500.model.extracredit.levelone;

/**
 * This is the enum for the rules.
 */
public enum Variant {
  FALLEN_ACE, REVERSE
}
