package cs3500.model.extracredit.leveltwo;

/**
 * This is the enum for the two rules.
 */
public enum Variant {
  SAME, PLUS
}
