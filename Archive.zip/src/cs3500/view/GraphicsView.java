package cs3500.view;

import java.awt.*;

public interface GraphicsView {

  // use rendering for this
  void render(Graphics g);

  void update(Graphics g);


}
