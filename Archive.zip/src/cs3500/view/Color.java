package cs3500.view;

public enum Color {
  RED,
  WHITE,
  YELLOW
}
