package cs3500.model;

/**
 * An enum class to represent the state of a cell.
 */
 public enum CellState {
  HOLE, CARD_SPACE, EMPTY;

  @Override
  public String toString() {
    return super.toString();
  }

}