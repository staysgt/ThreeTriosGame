package cs3500.model;

public interface Card {

  String getName();
  String toString();
  boolean equals(Object obj);

}
