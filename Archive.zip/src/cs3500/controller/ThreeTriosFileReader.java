package cs3500.controller;

public interface ThreeTriosFileReader {

}
