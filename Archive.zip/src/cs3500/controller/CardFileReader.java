package cs3500.controller;

/**
 * Interface that represents a CardFileReader
 */
public interface CardFileReader {



}
